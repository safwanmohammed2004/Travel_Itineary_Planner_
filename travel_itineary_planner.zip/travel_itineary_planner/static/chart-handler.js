document.addEventListener("DOMContentLoaded", () => {
    if (typeof budget !== "undefined" && budget.length > 0) {
        const totals = { food: 0, travel: 0, stay: 0, activities: 0 };

        budget.forEach(day => {
            totals.food += day.food || 0;
            totals.travel += day.travel || 0;
            totals.stay += day.stay || 0;
            if (day.activities) {
                totals.activities += day.activities.reduce((sum, a) => sum + (a.cost || 0), 0);
            }
        });

        const total = Object.values(totals).reduce((sum, val) => sum + val, 0);

        if (total > 0) {
            const ctx = document.getElementById("budgetChart").getContext("2d");

            const labels = [];
            const data = [];
            const backgroundColors = [];

            const gradientColors = [
                ['#b8c6db', '#f5f7fa'], // food - silver gradient
                ['#f3904f', '#3b4371'], // travel - orange-violet
                ['#4b6cb7', '#182848'], // stay - deep blue
                ['#c94b4b', '#4b134f']  // activities - crimson-purple
            ];

            const categories = ["food", "travel", "stay", "activities"];

            categories.forEach((cat, index) => {
                if (totals[cat] > 0) {
                    labels.push(cat.charAt(0).toUpperCase() + cat.slice(1));
                    data.push(totals[cat]);

                    const grad = ctx.createLinearGradient(0, 0, 300, 300);
                    grad.addColorStop(0, gradientColors[index][0]);
                    grad.addColorStop(1, gradientColors[index][1]);
                    backgroundColors.push(grad);
                }
            });

            new Chart(ctx, {
                type: "doughnut",
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: backgroundColors,
                        borderColor: "#ffffff",
                        borderWidth: 3,
                        hoverOffset: 30
                    }]
                },
                options: {
                    responsive: true,
                    cutout: "60%",
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: ctx => {
                                    const value = ctx.raw;
                                    const percent = ((value / total) * 100).toFixed(1);
                                    return `${ctx.label}: ₹${value} (${percent}%)`;
                                }
                            },
                            backgroundColor: "#222",
                            titleColor: "#fff",
                            bodyColor: "#ddd",
                            borderColor: "#555",
                            borderWidth: 1
                        },
                        legend: {
                            labels: {
                                color: "#eee",
                                font: {
                                    weight: "bold",
                                    size: 14
                                }
                            }
                        },
                        doughnutlabel: {
                            labels: [
                                {
                                    text: `₹${total}`,
                                    font: {
                                        size: '20',
                                        weight: 'bold'
                                    },
                                    color: '#fff'
                                },
                                {
                                    text: 'Total Budget',
                                    font: {
                                        size: '12'
                                    },
                                    color: '#aaa'
                                }
                            ]
                        }
                    },
                    animation: {
                        animateRotate: true,
                        animateScale: true,
                        duration: 1500,
                        easing: 'easeOutBounce'
                    }
                },
                plugins: [{
                    id: 'doughnutCenterText',
                    beforeDraw: function(chart) {
                        const { width } = chart;
                        const { height } = chart;
                        const ctx = chart.ctx;
                        ctx.restore();
                        const fontSize = (height / 150).toFixed(2);
                        ctx.font = `${fontSize}em sans-serif`;
                        ctx.textBaseline = "middle";

                        const text = `₹${total}`;
                        const textX = Math.round((width - ctx.measureText(text).width) / 2);
                        const textY = height / 2;

                        ctx.fillStyle = "#fff";
                        ctx.fillText(text, textX, textY);
                        ctx.save();
                    }
                }]
            });
        }
    }
});
