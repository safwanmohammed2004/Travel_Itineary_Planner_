from flask import Flask, render_template, request, redirect
import openai
import re
import random
import urllib.parse
import requests

app = Flask(__name__)
openai.api_key = "sk-proj-ZvmYjYLaXF5ApuOpMJF9yFGLxawVD8UQ-UbG2VX_LSgfKNO2q9zTXOTU8LFI0hOcLT3BlbkFJZLb7f7DaX4Ny58vBU7lfspDpX09ySlym7oeX12GWxfHewv6ogPd1tR0Lfoqzu4fYyTy9ckpZwA"

UNSPLASH_ACCESS_KEY = "mTBrVJrcrmflRxB-M5aalAX4xuoz74IGYwePQ9s"

def generate_star_rating():
    return "⭐" * random.randint(3, 5)

def format_plan_with_ratings(plan_text):
    lines = plan_text.split("\n")
    out = []
    for line in lines:
        if line.strip().startswith(("-", "•")):
            out.append(f"{line} <span class='rating'>{generate_star_rating()}</span>")
        else:
            out.append(line)
    return "<br>".join(out)

def parse_budgets(plan_text):
    pattern = re.compile(
        r'Day\s*(\d+).*?'
        r'(?:Food|Food Budget)[:\s]*[₹INR]*\s*(\d+).*?'
        r'(?:Travel|Travel Costs)[:\s]*[₹INR]*\s*(\d+).*?'
        r'(?:Stay|Accommodation)[:\s]*[₹INR]*\s*(\d+)',
        re.IGNORECASE | re.DOTALL
    )

    budgets = []
    for match in pattern.finditer(plan_text):
        budgets.append({
            "day": int(match.group(1)),
            "food": int(match.group(2)),
            "travel": int(match.group(3)),
            "stay": int(match.group(4))
        })

    return budgets

def fetch_place_images(place_name):
    try:
        url = f"https://api.unsplash.com/search/photos?page=1&query={urllib.parse.quote_plus(place_name)}&client_id={UNSPLASH_ACCESS_KEY}&orientation=landscape&per_page=5"
        response = requests.get(url)
        data = response.json()
        return [
            {
                "url": img['urls']['regular'],
                "description": img.get('description') or img.get('alt_description') or "Famous place"
            }
            for img in data.get('results', [])
        ]
    except Exception as e:
        print(f"Error fetching images: {e}")
        return []

@app.route("/", methods=["GET", "POST"])
def index():
    error = None
    result = None
    budgets = []
    show_flight_option = False
    user_source = ""
    user_destination = ""
    images = []

    if request.method == "POST":
        source = request.form.get("source")
        destination = request.form.get("destination")
        days = request.form.get("days")

        # NEW OPTIONAL FIELDS
        start_date = request.form.get("start_date")
        interest = request.form.get("interest")
        travel_mode = request.form.get("travel_mode")
        user_budget = request.form.get("budget")

        if not (source and destination and days):
            error = "Please fill out all required fields."
        else:
            user_source = source
            user_destination = destination

            prompt = (
                f"Generate a detailed day-wise travel itinerary from {source} to {destination} "
                f"for {days} days."
            )

            if start_date:
                prompt += f" Start the plan from {start_date}."
            if interest:
                prompt += f" The user is interested in {interest} travel."
            if travel_mode:
                prompt += f" Prefer {travel_mode} as the mode of transport."
            if user_budget:
                prompt += f" Budget preference is {user_budget} level."

            prompt += (
                " Include food, travel, and stay budgets per day in INR."
                " At the end list budgets in format: Day X - Food: Y INR, Travel: Z INR, Stay: W INR."
            )

            try:
                resp = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a helpful travel planner."},
                        {"role": "user", "content": prompt}
                    ]
                )
                plan_text = resp.choices[0].message.content
                result = format_plan_with_ratings(plan_text)
                budgets = parse_budgets(plan_text)
                show_flight_option = True
                images = fetch_place_images(destination)
            except Exception as e:
                error = f"Error generating plan: {e}"

    return render_template(
        "index.html",
        error=error,
        result=result,
        budget=budgets,
        show_flight_option=show_flight_option,
        source=user_source,
        destination=user_destination,
        images=images
    )

@app.route("/flights", methods=["POST"])
def flights():
    source = request.form.get("source")
    destination = request.form.get("destination")
    transport = request.form.get("transport")

    encoded_src = urllib.parse.quote_plus(source or "")
    encoded_dst = urllib.parse.quote_plus(destination or "")

    if transport == "train":
        return redirect("https://www.irctc.co.in/nget/train-search")
    elif transport == "bus":
        return redirect(f"https://www.redbus.in/search?fromCity={encoded_src}&toCity={encoded_dst}&onward=2024-06-20")
    else:
        return redirect(f"https://www.google.com/flights?hl=en#flt={encoded_src}.{encoded_dst}.2024-06-20")

if __name__ == "__main__":
    app.run(debug=True)
    