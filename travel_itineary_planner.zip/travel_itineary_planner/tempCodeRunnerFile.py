from flask import Flask, render_template, request, redirect
import openai
import re
import random

app = Flask(__name__)
openai.api_key = "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"

def generate_star_rating():
    return "⭐" * random.randint(3, 5)

def format_plan_with_ratings(plan_text):
    lines = plan_text.split("\n")
    out = []
    for line in lines:
        if line.strip().startswith(("-", "•")):
            out.append(f"{line} <span class='rating'>{generate_star_rating()}</span>")
        else:
            out.append(line)
    return "<br>".join(out)

def parse_budgets(plan_text):
    """
    Extracts budget data from itinerary text with improved pattern matching
    Handles multiple formats:
    - "Day 1 - Food: 1500 INR, Travel: 2000 INR, Stay: 3000 INR"
    - "Day 2: Food Budget: ₹2000, Travel Costs: ₹1500, Accommodation: ₹2500"
    """
    pattern = re.compile(
        r'Day\s*(\d+).*?'
        r'(?:Food|Food Budget)[:\s]*[₹INR]*\s*(\d+).*?'
        r'(?:Travel|Travel Costs)[:\s]*[₹INR]*\s*(\d+).*?'
        r'(?:Stay|Accommodation)[:\s]*[₹INR]*\s*(\d+)',
        re.IGNORECASE | re.DOTALL
    )
    
    budgets = []
    for match in pattern.finditer(plan_text):
        budgets.append({
            "day": int(match.group(1)),
            "food": int(match.group(2)),
            "travel": int(match.group(3)),
            "stay": int(match.group(4))
        })
    
    return budgets

@app.route("/", methods=["GET", "POST"])
def index():
    error = None
    result = None
    budgets = []
    show_flight_option = False

    if request.method == "POST":
        source = request.form.get("source")
        destination = request.form.get("destination")
        days = request.form.get("days")
        if not (source and destination and days):
            error = "Please fill out all fields."
        else:
            prompt = (
                f"Generate a detailed day-wise travel itinerary from {source} to {destination} "
                f"for {days} days. Include food, travel, and stay budgets per day in INR. "
                "At the end list budgets in format: Day X - Food: Y INR, Travel: Z INR, Stay: W INR."
            )
            try:
                resp = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a helpful travel planner."},
                        {"role": "user", "content": prompt}
                    ]
                )
                plan_text = resp.choices[0].message.content
                result = format_plan_with_ratings(plan_text)
                budgets = parse_budgets(plan_text)
                show_flight_option = True
            except Exception as e:
                error = f"Error generating plan: {e}"

    return render_template(
        "index.html",
        error=error,
        result=result,
        budget=budgets,
        show_flight_option=show_flight_option
    )

@app.route("/flights", methods=["POST"])
def flights():
    return redirect("https://www.google.com/flights")

if __name__ == "__main__":
    app.run(debug=True)
